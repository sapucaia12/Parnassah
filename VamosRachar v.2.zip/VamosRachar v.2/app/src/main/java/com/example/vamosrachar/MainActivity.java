package com.example.vamosrachar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements TextWatcher, View.OnClickListener, TextToSpeech.OnInitListener {
    EditText editConta, editPessoas;
    TextView textResultado;
    FloatingActionButton share, falar;
    TextToSpeech ttsPlayer;
    //int pessoas =0;
    //double valor = 0.0;
    String resultadoFormatado = "0,00";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editConta = (EditText) findViewById(R.id.editConta);
        editConta.addTextChangedListener(this);

        editPessoas = (EditText) findViewById(R.id.editPessoas);
        editPessoas.addTextChangedListener(this);

        textResultado = (TextView) findViewById(R.id.textResultado);
        share = (FloatingActionButton) findViewById(R.id.ButtonShare);
        share.setOnClickListener(this);

        falar = (FloatingActionButton) findViewById(R.id.ButtonFalar);
        falar.setOnClickListener(this);

        ttsPlayer=new TextToSpeech(this,this);

        Intent checkTTSIntent = new Intent();
        checkTTSIntent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
        startActivityForResult(checkTTSIntent, 1122);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1122) {
            if (requestCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {
                ttsPlayer = new TextToSpeech(this, this);
            } else {
                Intent installTTSIntent = new Intent();
                installTTSIntent
                        .setAction(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                startActivity(installTTSIntent);

            }
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable editable) {

        Log.v("Teste", editConta.getText().toString());
        try {


            double resultado = Double.parseDouble(editConta.getText().toString());
            double pessoas = Double.parseDouble(editPessoas.getText().toString());
            resultado = (resultado / pessoas);
            DecimalFormat df = new DecimalFormat("#.00");
            textResultado.setText(getString(R.string.R_S)+ df.format(resultado));


        } catch (Exception e) {
            textResultado.setText(R.string.R_0_00);
        }
    }

    @Override
    public void onClick(View view) {
        if (view == share) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.ValorShare) + textResultado.getText().toString());
            startActivity(intent);

        }

        if (view == falar) {
            if (ttsPlayer != null) {
                ttsPlayer.speak(getString(R.string.ValorPessoa) + textResultado.getText().toString() , TextToSpeech.QUEUE_FLUSH, null, "ID1");

            }
        }
        }
     @Override
     public void onInit(int status){
          if (status == TextToSpeech.SUCCESS) {
                Toast.makeText(this, R.string.TTsAtivado, Toast.LENGTH_LONG).show();
          }else if (status == TextToSpeech.ERROR) {
                    Toast.makeText(this, R.string.TTsNaoHabilitado, Toast.LENGTH_SHORT).show();
                }
            }

/* link das imagens, licença grátis mediante referência ao autor:
 imagem conta:  https://www.flaticon.com/authors/pixel-perfect
imagem mão : dinheiro:https://www.freepik.com
imagem volume: https://www.flaticon.com/authors/pixel-perfect
icone principal:https//br.freepik.comvetoresabstratoAbstrato vetor criado por vectorjuice - br.freepik.coma
 */
}
